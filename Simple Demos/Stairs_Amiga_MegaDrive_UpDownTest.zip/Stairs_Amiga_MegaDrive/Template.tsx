<?xml version="1.0" encoding="utf-8"?>
<tileset xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" name="templates" tilewidth="256" tileheight="256" tilecount="256" columns="0">
  <image source="templates.png" width="256" height="256" />
  <tile id="0">
    <properties>
      <property name="Name" value="new_actor" type="string" />
    </properties>
  </tile>
</tileset>